package com.ext.teamformation.Activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import com.ext.teamformation.R;

import java.util.ArrayList;

public class AddPeopleActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {
    ListView list;
    ListViewAdapter adapter;
    SearchView editsearch;
    String[] nameList, langList, expList,rating;

    ArrayList<AnimalNames> arraylist = new ArrayList<AnimalNames>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_people);
        // Generate sample data

        nameList = new String[]{"Agnesh", "Meet", "Satypal","Siddhi", "Nishtha", "Amiras", "Raj", "Ravi"};
        langList= new String[]{"JAVA, ANDROID", "ANDROID,C#", "C, C++, PHP, HTML","Java, REACT", "PYTHON, ANGULAR JS", "MYSQL, JAVASCRIPT", "JAVA, ADVANCED JAVA, ANDROID", "C, C++"};
        expList = new String[]{"3 Year", "4 Year", "3 Year 5 Months","2 Year", "3 Year", "2 Year 6 Months", "2 Year 10 Months", "5 Year"};
        rating = new String[]{"5 Star", "4.5 Star", "4.5 Star","4.5 Star", "5 Star", "3.5 Star", "4 Star", "3 Star"};
        // Locate the ListView in listview_main.xml
        list = (ListView) findViewById(R.id.lv);

        for (int i = 0; i < nameList.length; i++) {
            AnimalNames animalNames = new AnimalNames(nameList[i], langList[i], expList[i],rating[i]);
            // Binds all strings into an array
            arraylist.add(animalNames);
        }

        // Pass results to ListViewAdapter Class
        adapter = new ListViewAdapter(this, arraylist);

        // Binds the Adapter to the ListView
        list.setAdapter(adapter);
        list.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onItemClick (AdapterView<?> parent , View view , int position , long id) {
               // view.setBackgroundColor(getColor(R.color. colorPrimaryDark )) ;
               view.setBackgroundColor(Color.parseColor("#ffc900"));
            }
        }) ;

        // Locate the EditText in listview_main.xml
        editsearch = (SearchView) findViewById(R.id.search);
        editsearch.setOnQueryTextListener(this);
    }


    @Override
    public boolean onQueryTextSubmit(String query) {

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        String text = newText;
        adapter.filter(text);
        return false;
    }
}