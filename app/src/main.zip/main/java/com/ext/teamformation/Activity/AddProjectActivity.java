package com.ext.teamformation.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.ext.teamformation.R;

public class AddProjectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_project);
    }
    public void alert(View v) {
        Toast.makeText(this, "You Adds Project Succesfully", Toast.LENGTH_SHORT).show();
    }

}
